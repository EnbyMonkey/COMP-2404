Emile Greer
100914184

To compile, run make or make all in terminal.
The executable is named a1-global.

List of files:
Date.h, Date.cc: defines the Date class
Student.h, Student.cc: defines Student class
Room.h, Room.cc: defines the Room class
Reservation.h, Reservation.cc: defines the Reservation class
Library.h, Library.cc: defines the Library class
a1-global.cc: includes the main function, as well as the functions for testing correctness
