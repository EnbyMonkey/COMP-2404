#include<iostream>
#include<string>

using namespace std;

int main(){
	cout << "Please enter two integers: "<<endl;
	int x1, x2;
	cin >> x1;
	cin >> x2;
	cout << "The product of " << x1 << " and " << x2 << " is " << x1*x2 << "!" << endl;
	return 0;
}
