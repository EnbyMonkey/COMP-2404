#include<cmath>

using namespace std;

void power(int a, int b, int& c) {
	c = pow(a, b);
}
