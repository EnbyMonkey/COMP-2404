#include "Array.h"

using namespace std;

template<class T> Array<T>::Array() : size(0) { }
template<class T> Array<T>::~Array() { delete [] elements; }

// other
template<class T>
void Array<T>::add(T t) { if (size < MAX_ARR) elements[size++] = t; }

template<class T>
int Array<T>::getSize() const {	return size; }

template<class T>
bool Array<T>::isFull() const {	return size >= MAX_ARR; }

// overload [] operator
template<class T>
T Array<T>::operator[](int index) {
  if (index < 0 || index >= size) {
		cerr<<"Array index out of bounds"<<endl;
		exit(1);
	}
	return elements[index];
}

// overload << operator
template<class T>
ostream& operator<<(ostream& output, const T t) {
  output << t.print();
  return output;
}
